package com.cts.CreditScoreModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditScoreModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
